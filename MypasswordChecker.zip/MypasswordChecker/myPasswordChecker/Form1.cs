﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myPasswordChecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            int index = 0;
            String text = textBox1.Text;

            if(text.Length==0)
            {
                listBox1.Items.Add("please enter your password");
                return;
            }
           else if (text.Length >= 15)
            {
                index += 75;
               
            }
            else if (text.Length >=10 || text.Length <= 14)
            {
                index += 60;
               
            }
            else if(text.Length >=7 || text.Length <= 9)
            {
                index += 40;
               ;
            }
            else if(text.Length >= 4 || text.Length < 7)
            {
                index += 20;
               
            }
            if (checkNumbers(text)) index += 10;
            if (checkSymbolsAndPunctuations(text)) index += 15;
            if (checkLetters(text)) index += 15;

            PasswordPower(index);
            if (listBox1.Items.Count > 0) return;

            listBox1.Items.Add("No Problem has been found");




        }
        bool checkNumbers(String text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];

                if (!char.IsDigit(c)) continue;
                return true;
            }

            listBox1.Items.Add("Password doesn't have any Numbers");

            return false;

        }
        bool checkSymbolsAndPunctuations(String text)
        {
            bool hasSymbols = false;
            bool hasPunctuations = false;

            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];

                if (char.IsSymbol(c)) hasSymbols = true;
                if (char.IsPunctuation(c)) hasPunctuations = true;
            }

            if (!(hasSymbols || hasPunctuations))
                listBox1.Items.Add("Password doesn't have any sign character");

            return hasSymbols || hasPunctuations;
        }
        bool checkLetters(String text)
        {
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];

                if (!char.IsLetter(c)) continue;
                return true;
            }

            listBox1.Items.Add("Password doesn't have any Letters");

            return false;
        }

        private void PasswordPower(int index)
        {
            if (index >= 90) label3.Text = "Very strong";
            if (index >= 75 && index < 90) label3.Text = "Strong";
            if (index >= 50 && index < 75) label3.Text = "Medium";
            if (index >= 25 && index < 50) label3.Text = "Weak";
            if (index < 25) label3.Text = "Very weak";
        }

    }
}

